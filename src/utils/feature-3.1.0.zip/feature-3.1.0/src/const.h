// FEATURE
// See COPYING and AUTHORS for copyright and license agreement terms.

// $Id: const.h 1101 2011-09-12 08:43:33Z mikewong899 $

#ifndef CONST_H
#define CONST_H

// FEATURE constants
#define FeatureDirEnvStr        "FEATURE_DIR"
#define PdbDirEnvStr            "PDB_DIR"
#define DsspDirEnvStr           "DSSP_DIR"

#endif

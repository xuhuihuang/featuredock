This is a copy of feature 3.1.0 by Altman et al
